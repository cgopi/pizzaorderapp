--/**
-- * CREATE Script for init of DB
-- */

---- Create DB for pizza order (size, variety of pizza, toppings, deals) from customers

insert into order (id, date_created, deleted, size, variety, topping, deal, price, order_status, username) values (1, now(), false, 'regular', 'cheese', 'onion',
1, 12, 'ORDERED', 'user1');

insert into order (id, date_created, deleted, size, variety, topping, deal, price, order_status, username) values (2, now(), false, 'medium', 'chicken', 'tomato',
2, 15, 'CANCELED', 'user22');

insert into order (id, date_created, deleted, size, variety, topping, deal, price, order_status, username) values (3, now(), false, 'large', 'beef', 'spinach',
3, 17, 'CONFIRMED', 'user3');


