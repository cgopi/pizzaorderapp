package com.app.pizzaorder.controller.mapper;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.app.pizzaorder.datatransferobject.OrderDTO;
import com.app.pizzaorder.domainobject.OrderDO;

/**
 *
 */
public class OrderMapper
{
    /**
     * @param orderDTO
     * @return
     */
    public static OrderDO makeOrderDO(OrderDTO orderDTO)
    {
        return new OrderDO(orderDTO.getUsername());
    }


    /**
     * @param orderDO
     * @return
     */
    public static OrderDTO makeOrderDTO(OrderDO orderDO)
    {
        OrderDTO.OrderDTOBuilder orderDTOBuilder = OrderDTO.newBuilder()
            .setOrderId(orderDO.getOrderId())
            .setUsername(orderDO.getUsername())
            .setDateCreated(orderDO.getDateCreated())
            .setOrderStatus(orderDO.getOrderStatus())
            .setSize(orderDO.getSize())
            .setVariety(orderDO.getVariety())
            .setTopping(orderDO.getTopping())
            .setDeal(orderDO.getDeal())
            .setPrice(orderDO.getPrice());

        return orderDTOBuilder.createOrderDTO();
    }


    /**
     * @param orders
     * @return
     */
    public static List<OrderDTO> makeDriverDTOList(Collection<OrderDO> orders)
    {
        return orders.stream()
            .map(OrderMapper::makeOrderDTO)
            .collect(Collectors.toList());
    }
}
