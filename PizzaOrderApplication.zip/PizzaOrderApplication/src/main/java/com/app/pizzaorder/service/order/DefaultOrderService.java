package com.app.pizzaorder.service.order;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.pizzaorder.dataaccessobject.OrderRepository;
import com.app.pizzaorder.domainobject.OrderDO;
import com.app.pizzaorder.domainvalue.OrderStatus;
import com.app.pizzaorder.exception.ConstraintsViolationException;
import com.app.pizzaorder.exception.EntityNotFoundException;

/**
 * Service to encapsulate the link between DAO and controller and to have business logic for some order specific things.
 * <p/>
 */
@Service
public class DefaultOrderService implements OrderService
{

	private final OrderRepository orderRepository;

	/**
	 * @param orderRepository
	 */
	public DefaultOrderService(final OrderRepository orderRepository)
	{
		this.orderRepository = orderRepository;
	}

	/**
	 * Selects an order by id.
	 *
	 * @param orderId
	 * @return found order
	 * @throws EntityNotFoundException if no order with the given id was found.
	 */
	@Override
	public OrderDO find(Long orderId) throws EntityNotFoundException
	{
		return findOrderChecked(orderId);
	}

	/**
	 * Creates a new order.
	 *
	 * @param orderDO
	 * @return
	 * @throws ConstraintsViolationException if a order already exists with the given username, ... .
	 */
	@Override
	public OrderDO create(OrderDO orderDO) throws ConstraintsViolationException
	{
		OrderDO order;
		double price;
		try
		{
			order = orderRepository.save(orderDO);
			if (order.getOrderStatus().equals(OrderStatus.ORDERED)) {
				//Write logic to find price based on size of pizza, variety of pizza, toppings(if any), deals(if any)
				if ("regular".equals(order.getSize()) && "cheese".equals(orderDO.getVariety())) {
					if ("onion".equals(orderDO.getTopping())) {
						price = 11.00d;
					} else {
						price = 9.00d;
					}
					order.setPrice(price);
				} 
				
				if ("medium".equals(order.getSize()) && "chicken".equals(orderDO.getVariety())) {
					if ("tomato".equals(orderDO.getTopping())) {
						price = 13.00d;
					} else {
						price = 11.00d;
					}
					order.setPrice(price);
				}
				
				if ("large".equals(order.getSize()) && "beef".equals(orderDO.getVariety())) {
					if ("spinach".equals(orderDO.getTopping())) {
						price = 15.00d;
						if (order.getDeal() == 2L) { //2 percent deal
							price = 14.7d; 
						}
					} else {
						price = 13.00d;
						if (order.getDeal() == 2L) { //2 percent deal
							price = 12.74d; 
						}
					}
					order.setPrice(price);
				}
			}
		}
		catch (DataIntegrityViolationException e)
		{
			Logger.getLogger("DefaultOrderService").warning("ConstraintsViolationException while creating a order");
			throw new ConstraintsViolationException(e.getMessage());
		}
		return order;
	}


	/**
	 * Deletes an existing order by id.
	 *
	 * @param orderId
	 * @throws EntityNotFoundException if no order with the given id was found.
	 */
	@Override
	@Transactional
	public void delete(Long orderId) throws EntityNotFoundException
	{
		OrderDO orderDO = findOrderChecked(orderId);
		orderDO.setDeleted(true);
	}


	/**
	 * Update the order.
	 *
	 * @param orderId
	 * @param orderStatus
	 * @throws EntityNotFoundException
	 */
	@Override
	@Transactional
	public void update(long orderId, OrderStatus orderStatus) throws EntityNotFoundException
	{
		OrderDO orderDO = findOrderChecked(orderId);
		orderDO.setOrderStatus(orderStatus);
	}

	/**
	 * @param orderId
	 * @return
	 * @throws EntityNotFoundException
	 */
	private OrderDO findOrderChecked(Long orderId) throws EntityNotFoundException
	{
		return orderRepository.findById(orderId)
				.orElseThrow(() -> new EntityNotFoundException("Could not find entity with id: " + orderId));
	}

	@Override
	public List<OrderDO> find(OrderStatus orderStatus) throws EntityNotFoundException {
		return orderRepository.findByOrderStatus(orderStatus);
	}

}