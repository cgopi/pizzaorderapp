package com.app.pizzaorder.datatransferobject;

import java.time.ZonedDateTime;

import javax.validation.constraints.NotNull;

import com.app.pizzaorder.domainvalue.OrderStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderDTO
{
	@JsonIgnore
	private Long orderId;

	@NotNull(message = "Username can not be null!")
	private String username;

	private ZonedDateTime dateCreated;

	private OrderStatus orderStatus;

	private String size;

	private String variety;

	private String topping;

	private Long deal;    
	
	private double price;
	
	private OrderDTO()
	{
	}


	/**
	 * @param id
	 * @param username
	 * @param dateCreated
	 * @param orderStatus
	 * @param size
	 * @param variety
	 * @param topping
	 * @param deal
	 * @param price
	 */
	private OrderDTO(Long orderId, 
			String username,
			ZonedDateTime dateCreated, 
			OrderStatus orderStatus,
			String size, 
			String variety, 
			String topping, 
			Long deal,
			double price)
	{
		this.orderId = orderId;
		this.username = username;
		this.dateCreated = dateCreated;
		this.orderStatus = orderStatus;
		this.size = size;
		this.variety = variety;
		this.topping = topping;
		this.deal = deal;
		this.price = price;
	}


	/**
	 * @return
	 */
	public static OrderDTOBuilder newBuilder()
	{
		return new OrderDTOBuilder();
	}


	/**
	 * @return
	 */
	@JsonProperty
	public Long getOrderId()
	{
		return orderId;
	}


	/**
	 * @return
	 */
	public String getUsername()
	{
		return username;
	}


	/**
	 * @return
	 */
	public ZonedDateTime getDateCreated()
	{
		return dateCreated;
	}


	/**
	 * @return
	 */
	public OrderStatus getOrderStatus()
	{
		return orderStatus;
	}


	/**
	 * @return
	 */
	public String getSize()
	{
		return size;
	}


	/**
	 * @return
	 */
	public String getVariety()
	{
		return variety;
	}


	/**
	 * @return
	 */
	public String getTopping()
	{
		return topping;
	}


	/**
	 * @return
	 */
	public Long getDeal()
	{
		return deal;
	}
	
	
	/**
	 * @return
	 */
	public double getPrice()
	{
		return price;
	}


	public static class OrderDTOBuilder
	{
		private Long orderId;
		private String username;
		private ZonedDateTime dateCreated;
		private OrderStatus orderStatus;
		private String size;
		private String variety; 
		private String topping; 
		private Long deal;
		private double price;


		/**
		 * @param orderId
		 * @return
		 */
		public OrderDTOBuilder setOrderId(Long orderId)
		{
			this.orderId = orderId;
			return this;
		}


		/**
		 * @param username
		 * @return
		 */
		public OrderDTOBuilder setUsername(String username)
		{
			this.username = username;
			return this;
		}


		/**
		 * @param dateCreated
		 * @return
		 */
		public OrderDTOBuilder setDateCreated(ZonedDateTime dateCreated)
		{
			this.dateCreated = dateCreated;
			return this;
		}


		/**
		 * @param orderStatus
		 * @return
		 */
		public OrderDTOBuilder setOrderStatus(OrderStatus orderStatus) 
		{
			this.orderStatus = orderStatus;
			return this;
		}


		/**
		 * @param size
		 * @return
		 */
		public OrderDTOBuilder setSize(String size) 
		{
			this.size = size;
			return this;
		}


		/**
		 * @param variety
		 * @return
		 */
		public OrderDTOBuilder setVariety(String variety) 
		{
			this.variety = variety;
			return this;
		}

		/**
		 * @param topping
		 * @return
		 */
		public OrderDTOBuilder setTopping(String topping) 
		{
			this.topping = topping;
			return this;
		}

		/**
		 * @param price
		 * @return
		 */
		public OrderDTOBuilder setPrice(double price) 
		{
			this.price = price;
			return this;
		}
		
		/**
		 * @param deal
		 * @return
		 */
		public OrderDTOBuilder setDeal(Long deal) 
		{
			this.deal = deal;
			return this;
		}

		/**
		 * @return
		 */
		public OrderDTO createOrderDTO()
		{
			return new OrderDTO(orderId, username, dateCreated, orderStatus, size, variety, topping, deal, price);
		}

	}
}