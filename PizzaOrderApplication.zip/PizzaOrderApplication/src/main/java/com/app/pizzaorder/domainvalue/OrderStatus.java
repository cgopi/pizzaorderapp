package com.app.pizzaorder.domainvalue;

/**
 *
 */
public enum OrderStatus
{
    ORDERED, DELIVERED, CANCELED, 
}
