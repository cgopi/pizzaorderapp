package com.app.pizzaorder.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.app.pizzaorder.domainobject.OrderDO;
import com.app.pizzaorder.domainvalue.OrderStatus;
import com.app.pizzaorder.service.order.OrderService;

/**
 * Test controller for maintaining orders.
 */
public class OrderControllerTest {

	private OrderService service;
	private MockMvc mockMvc;
	private OrderController controller;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		service = mock(OrderService.class);		
		controller = PowerMockito.spy(new OrderController(service));
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
	
	@Test
	public void testGetOrder() throws Exception {
		MvcResult result = mockMvc.perform(get("/v1/orders")
    			.param("orderId", "1"))    			
    			.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());		
	}
	
	@Test
	public void testGetOrder_Error() throws Exception {
		MvcResult result = mockMvc.perform(get("/v1/orders")
    			.param("orderId", "-1"))    			
    			.andExpect(status().isBadRequest())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertEquals(400, response.getStatus());
	}
	
	@Test
	public void testCreateOrder() throws Exception {
		OrderDO orderDO = new OrderDO("PizzaUser");
		orderDO.setId(1L);
		orderDO.setDeleted(false);
		orderDO.setSize("medium");
		orderDO.setOrderStatus(OrderStatus.ORDERED);
		orderDO.setTopping("onion");
		orderDO.setVariety("cheese");
		Mockito.when(service.create(Mockito.any(OrderDO.class))).thenReturn(orderDO);
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/v1/orders"))
				.andExpect(status().isCreated())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(201, response.getStatus());
	}
	
	@Test
	public void testDeleteOrder() throws Exception {
		Mockito.doNothing().when(service).delete(Mockito.anyLong());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/orders")
				.param("id", "1"))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	//@Test
	public void testDeleteOrder_Error() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/v1/orders")
				.param("id", "-1"))
				.andExpect(status().isForbidden())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertEquals(403, response.getStatus());
	}
	
	@Test
	public void testUpdateOrder() throws Exception {
		Mockito.doNothing().when(service).update(Mockito.anyLong(), Mockito.anyObject());
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put("/v1/orders")
				.param("orderId", "1")
				.param("orderStatus",  OrderStatus.CANCELED.toString()))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	@Test
	public void testFindOrders() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/v1/orders")
				.param("orderStatus", OrderStatus.ORDERED.toString()))
				.andExpect(status().isOk())
    			.andReturn();
    	MockHttpServletResponse response = result.getResponse();
		assertNotNull(response);
		assertEquals(200, response.getStatus());
	}
	
	@After
	public void tearDown() {
		mockMvc = null;
		service = null;
		controller = null;
	}
	
}